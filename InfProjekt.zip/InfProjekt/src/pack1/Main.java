package pack1;

public class Main {

	public static void main(String[] args) {
		new Gui();	 
		new Var();
		new KeyHolder();
		new Label();

	}

}

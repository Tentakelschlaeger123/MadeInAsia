package pack1;

import javax.swing.JLabel;

public class Label extends JLabel{

	private static final long serialVersionUID = 1L;
	
}

package pack1;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHolder implements KeyListener{

	@Override
	public void keyPressed(KeyEvent arg0) {
		if(arg0.getKeyCode()==KeyEvent.VK_UP) {
			Var.moveup = true;
		}
		
		if(arg0.getKeyCode()==KeyEvent.VK_LEFT) {
			Var.moveleft = true;
		}
		
		if(arg0.getKeyCode()==KeyEvent.VK_DOWN) {
			Var.movedown = true;
		}
		
		if(arg0.getKeyCode()==KeyEvent.VK_RIGHT) {
			Var.moveright = true;
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		if(arg0.getKeyCode()==KeyEvent.VK_UP) {
			Var.moveup = false;
		}
		
		if(arg0.getKeyCode()==KeyEvent.VK_LEFT) {
			Var.moveleft = true;
		}
		
		if(arg0.getKeyCode()==KeyEvent.VK_DOWN) {
			Var.movedown = true;
		}
		
		if(arg0.getKeyCode()==KeyEvent.VK_RIGHT) {
			Var.moveright = true;
		}
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		
		
	}
	
	
}

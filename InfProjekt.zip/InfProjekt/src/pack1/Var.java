package pack1;

import javax.swing.JFrame;

public class Var {
	static JFrame jf1;
	static int width = 800, height = 600;
	static boolean moveup = false,movedown = false,moveleft= false,moveright= false;
	static Label lbl1;
	public Var() {
		
	}
}

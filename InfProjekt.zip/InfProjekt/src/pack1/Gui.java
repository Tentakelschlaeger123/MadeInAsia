package pack1;

import javax.swing.JFrame;

public class Gui {
	public Gui() {
		Var.jf1 = new JFrame();
		Var.jf1.setSize(Var.width, Var.	height);
		Var.jf1.setLocationRelativeTo(null);
		Var.jf1.setVisible(true);
		Var.jf1.setTitle("MadeInAsia");
		Var.jf1.setResizable(false);
		
		Var.lbl1 = new Label();
		Var.lbl1.setBounds(0,0,Var.width,Var.height);
		Var.lbl1.add(Var.jf1);
	}
}

package infprojekt;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferStrategy;
import javax.swing.JFrame;


public class Game extends JFrame implements Runnable, WindowListener {
	public static final int FPS = 60;
	public static final long maxLoopTime = 1000 / FPS;
	public static final int SCREEN_WIDTH = 1000 ;
	public static final int SCREEN_HEIGHT = 640;

	public Screen screen;
	KeyManager keyManager;
	BufferStrategy bs;
	Graphics g;
	AnimEntity fire;
	Canvas canvas;
	State menuState;
	State gameState;

	public static void main(String[] arg) {
		Game game = new Game();
		new Thread(game).start();
	}
	
	boolean running = true;
	@Override
	public void run() {
		addWindowListener(this);
		long timestamp;
		long oldTimestamp;

		screen = new Screen("Game", SCREEN_WIDTH, SCREEN_HEIGHT);
		keyManager = new KeyManager();
		screen.getFrame().addKeyListener(keyManager);
		canvas = screen.getCanvas();
		gameState = new GameState(this);
		menuState = new MenuState(this);
		State.setState(menuState);
		
		while(running) {
			oldTimestamp = System.currentTimeMillis();
			update();
			timestamp = System.currentTimeMillis();
			if(timestamp-oldTimestamp > maxLoopTime) {
				System.out.println("Wir sind zu sp�t!");
				continue;
			}
			render();
			timestamp = System.currentTimeMillis();
			System.out.println(maxLoopTime + " : " + (timestamp-oldTimestamp));
			if(timestamp-oldTimestamp <= maxLoopTime) {
				try {
					Thread.sleep(maxLoopTime - (timestamp-oldTimestamp) );
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		
		
	}
	void update() {
		keyManager.update();
		
		 Point p = keyManager.getInput();
		  if(p.x == -99) {
		    if(p.y == KeyEvent.VK_ESCAPE) {
		     State.setState(menuState);
		    }
		  
		  if(State.getState() != null) {
		    State.getState().update();
		  }
		  }}
	
	void render() {
		  Canvas c = screen.getCanvas();
		  bs = c.getBufferStrategy();
		  if(bs == null){
		    screen.getCanvas().createBufferStrategy(3);
		    return;
		  }
		  g = bs.getDrawGraphics();
		  
		  g.clearRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
		 if(State.getState() != null) {
			 State.getState().render(g);
		 }
		  bs.show();
		  g.dispose();
		}
	
	public KeyManager getKeyManager() {
		return keyManager;
	}
	
	public Canvas getCanvas() {
		return canvas;
		
	}
	public void gameStop() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
	
	
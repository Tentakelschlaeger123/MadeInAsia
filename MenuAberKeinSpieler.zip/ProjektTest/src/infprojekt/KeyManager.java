package infprojekt;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyManager implements KeyListener {

  private boolean[] keys;
  public boolean up, down, left, right, escape, enter;

  public KeyManager(){
    keys = new boolean[256];
  }
  public void update(){
    up = keys[KeyEvent.VK_W];
    down = keys[KeyEvent.VK_S];
    left = keys[KeyEvent.VK_A];
    right = keys[KeyEvent.VK_D];
    escape = keys[KeyEvent.VK_ESCAPE];
    enter = keys[KeyEvent.VK_ENTER];
  }
    
  @Override
  public void keyPressed(KeyEvent e) {
    keys[e.getKeyCode()] = true;
  }
  @Override
  public void keyReleased(KeyEvent e) {
    keys[e.getKeyCode()] = false;
  }
  @Override
  public void keyTyped(KeyEvent e) {
  }
  
  public Point getInput(){
	    int xMove = 0;
	    int yMove = 0;
	    if(up) {
	      yMove = -1;
	    }
	    if(down)
	      yMove = 1;
	    if(left)
	      xMove = -1;
	    if(right)
	      xMove = 1;
	    if(escape) {
	      xMove = -99;
	      yMove = KeyEvent.VK_ESCAPE;
	    }
	    if(enter) {
	    	xMove =-99;
	    	yMove = KeyEvent.VK_ENTER;
	    }
	  return new Point(xMove, yMove);
	  }
  
 
}

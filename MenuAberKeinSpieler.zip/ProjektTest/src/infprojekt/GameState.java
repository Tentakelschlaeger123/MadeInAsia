package infprojekt;

import java.awt.Graphics;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.HashSet;

public class GameState extends State {

	// player
private Player player;
Camera gameCamera;
private Level level;
Screen screen;
private Game game;
private AnimEntity fire;
		
@SuppressWarnings({"unchecked", "rawtypes"})
		
public GameState(Game game) {
	super(game);
	//this.game = game;
	
			
			TileSet[] tileSet = new TileSet[3];
			
			@SuppressWarnings({"unchecked", "rawtypes"})
			
			HashSet hs = new HashSet(Arrays.asList(0, 1, 2, 12, 14, 24, 25, 26, 28));
			tileSet[0] = new TileSet("/tiles/rpg2.png", 12 , 12, 3 , hs);
			
			hs = new HashSet(Arrays.asList(160, 161, 072, 075, 88,  91, 104, 105, 106, 107, 72, 75));
			tileSet[1] = new TileSet("/tiles/tileb.png", 16, 16, 0, hs);
			
			tileSet[2] = new TileSet("/tiles/tileb.png", 16, 16, 0, hs);
			
			String[] paths = new String[3];
			paths[0] = "/level/testlvl.txt";
			paths[1] = "/level/level1a.txt";
			paths[2] = "/level/level1b.txt";
			level = new Level(this, paths, tileSet);

			SpriteSheet playerSprite = new SpriteSheet("/sprites/player.png", 3, 4, 64, 64);
			player = new Player(this, level, 320, 320, playerSprite);
			SpriteSheet fireSprite = new SpriteSheet("/sprites/fire_big.png", 3, 1, 64, 128);
			fire = new AnimEntity(this, "Fire", fireSprite, 450, 380, 64, 192);
			
			gameCamera = new Camera(0, 0);
		}
			
	
		
	@Override
	public void update() {
		
		player.setMove(game.getKeyManager().getInput());
		System.out.println("KK");
  		player.update();
  		System.out.println("KK");
  		try {
	  	Thread.sleep(15);
  		} catch (InterruptedException e) {
  			e.printStackTrace();
  		};
	}

	@Override
	public void render(Graphics g) {
		level.render(g);
		player.render(g);
		level.renderZ(g);
		fire.render(g);
	}

	public Camera getGameCamera(){
		return gameCamera;
	}



}



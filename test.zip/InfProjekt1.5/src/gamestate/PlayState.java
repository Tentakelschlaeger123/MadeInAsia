package gamestate;

import infprojekt.Camera;
import infprojekt.Game;
import infprojekt.GameStateManager;
import infprojekt.Level;

import java.util.ArrayList;
import java.util.Arrays;


import java.util.HashSet;

import infprojekt.Player;
import infprojekt.Screen;
import infprojekt.SpriteSheet;
import infprojekt.TileSet;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;



public class PlayState extends GameState{
	
	// player
private Player player;
Camera gameCamera;
private Level level;
Screen screen;
		
@SuppressWarnings({"unchecked", "rawtypes"})
		
public PlayState(Game game) {
	super(game);
			
			TileSet[] tileSet = new TileSet[3];
			
			@SuppressWarnings({"unchecked", "rawtypes"})
			HashSet hs = new HashSet(Arrays.asList(0,1,2,13,14,24,25,26));
			tileSet[0] = new TileSet("/tiles/rpg.png", 12 /*sizeX*/, 12/*sizeY*/, 0 /*sizeZ*/, 3 /*border*/, hs);
			tileSet[1] = new TileSet("/tiles/tileb.png", 16, 16, 3, 0, hs);
			// Transparent Z / foreground layer tileset, no blocking tiles
			//tileSet[2] = new TileSet("/tiles/tilec.png", 17, 16, 3, 0, hs);
	 		String[] paths = new String[3];
	 		paths[0] = "/level/level1.txt";
	 		paths[1] = "/level/level1a.txt";
	 		paths[2] = "/level/level1b.txt";
	 		level = new Level(this, paths, tileSet);
			SpriteSheet playerSprite = new SpriteSheet("/sprites/player.png", 3, 4, 64, 64);
			player = new Player(this, level, 320, 320, playerSprite);
			gameCamera = new Camera(0, 0);
		}
			
	
		
	@Override
	public void update() {
		player.setMove(game.getKeyManager().getInput());
		System.out.println("KK");
  		player.update();
  		System.out.println("KK");
  		try {
	  	Thread.sleep(15);
  		} catch (InterruptedException e) {
  			e.printStackTrace();
  		};
	}

	@Override
	public void render(Graphics g) {
		level.render(g);
		player.render(g);
		level.renderZ(g);
	}

	public Camera getGameCamera(){
		return gameCamera;
	}
}

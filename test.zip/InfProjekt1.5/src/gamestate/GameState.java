package gamestate;

import java.awt.Graphics;

import infprojekt.Camera;
import infprojekt.Game;
import infprojekt.GameStateManager;


public abstract class GameState {
	
	
	
	private static GameState currentState = null;
	
	public static void setGameState(GameState state) {
		currentState = state;
	}
	public static GameState getGameState() {
		return currentState;
	}
	protected Game game;
	public GameState(Game game) {
		this.game = game;
	}
	
	
	public abstract void update();
	public abstract void render(Graphics g);
	
}
package infprojekt;

import java.awt.Graphics;

import gamestate.PlayState;

public class Player extends Creature {
  public static final int MARGIN_HORIZ = 14;
  public static final int MARGIN_VERT = 2;
  public static final int DEFAULT_HEALTH = 100;
  public static final int DEFAULT_SPEED = 2;
  private Game game;
  private PlayState state;

  public Player(PlayState state, Level level, int x, int y, SpriteSheet playerSprite) {
    super("Player", level, playerSprite, x, y, Entity.DEFAULT_WIDTH, Entity.DEFAULT_HEIGHT, Player.DEFAULT_HEALTH, Player.DEFAULT_SPEED);
   // this.game = game;
    this.state = state;
  }

  @Override
  public void update() {
	  System.out.println("KK3");
   // move();
    System.out.println("KK43");
    state.getGameCamera().centerOnEntity(this);
  }
  @Override
  public void render(Graphics g) {
    g.drawImage(image, entityX - state.getGameCamera().getxOffset(), entityY - state.getGameCamera().getyOffset(), width, height, null);
  }
  
  
}
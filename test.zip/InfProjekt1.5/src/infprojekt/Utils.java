package infprojekt;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class Utils {
	
	
	
  public static int parseInt(String number){
    try {
      return Integer.parseInt(number);
    } catch(NumberFormatException e){
      e.printStackTrace();
      return -1;
    }
  }
  public static String loadFileAsString(String path){
	  StringBuilder builder = new StringBuilder();
	  FileReader file = null;
	  //Get file from resources folder
	  URL in = Utils.class.getResource(path);
	  try {
	    file = new FileReader(in.getFile());
	  } catch (FileNotFoundException e1) {
	    e1.printStackTrace();
	    System.out.println("NOO");
	  }
	  if(file != null) {
	    try {
	      BufferedReader br = new BufferedReader(file);
	      String line;
	      while((line = br.readLine()) != null) {
	        builder.append(line + "\n");
	      }
	      br.close();
	    } catch(IOException e) {
	    	System.out.println("NOO2");
	      e.printStackTrace();
	    }
	  }
	  return builder.toString();
	}
  
  public static boolean containsBlock(int[][] touched) { //von getTilesTouched() zur�ckgegebene Array auf geblockte Kacheln �berpr�ft
	  for(int j = 0; j < touched.length; j++) {
	    for(int i = 0; i < touched[j].length; i++) {
	      if(touched[j][i] > 65535) return true;
	    }
	  }
	  return false;
	}
  
}
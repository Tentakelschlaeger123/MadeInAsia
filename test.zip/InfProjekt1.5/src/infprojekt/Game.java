package infprojekt;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashSet;
import gamestate.PlayState;
import gamestate.GameState;
import gamestate.MenuState;



public class Game implements Runnable {
	public static final int FPS = 60;
	public static final long maxLoopTime = 1000 / FPS;
	public static final int SCREEN_WIDTH = 640;
	public static final int SCREEN_HEIGHT = 640;

	public static int alpha = 0xFFFF00DC;
	
	public Screen screen;
	Player player;
	Level level;
	KeyManager keyManager;
	GameState playState;
	GameState menuState;
	Canvas canvas;
	
	
	
	BufferStrategy bs;
	Graphics g;
	Graphics2D g2;
	
	private GameStateManager gsm;

	public static void main(String[] arg) {
		Game game = new Game();
		new Thread(game).start();
	}
	
	@Override
	public void run() {
		//addWindowListener(this);
		long timestamp;
		long oldTimestamp;

		screen = new Screen("Game", SCREEN_WIDTH, SCREEN_HEIGHT);
		keyManager = new KeyManager();
		screen.getFrame().addKeyListener(keyManager);
		
		playState = new PlayState(this);
		menuState = new MenuState(this);
		GameState.setGameState(playState);

		
		while(true) {
			oldTimestamp = System.currentTimeMillis();
			update();
			timestamp = System.currentTimeMillis();
			if(timestamp-oldTimestamp > maxLoopTime) {
				System.out.println("Wir sind zu sp�t!");
				continue;
			}
			render();
			timestamp = System.currentTimeMillis();
			//System.out.println(maxLoopTime + " : " + (timestamp-oldTimestamp));
			if(timestamp-oldTimestamp <= maxLoopTime) {
				try {
					Thread.sleep(maxLoopTime - (timestamp-oldTimestamp) );
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	void update() {
		keyManager.update();
		
			  Point p = keyManager.getInput();
			  if(p.x == -99) {
			    if(p.y == KeyEvent.VK_ESCAPE) {
			      GameState.setGameState(menuState);
			    }
			  }
			  if(GameState.getGameState() != null) {
			    GameState.getGameState().update();
			  }
	
		
		
	}
	
		void render() {
			  Canvas c = screen.getCanvas();
			  bs = c.getBufferStrategy();
			  if(bs == null){
			    screen.getCanvas().createBufferStrategy(3);
			    return;
			  }
			  g = bs.getDrawGraphics();
			  //Clear Screen
			  g.clearRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
			  if(GameState.getGameState() != null)
			      GameState.getGameState().render(g);
			 
			  bs.show();
			  g.dispose();
			 
			}
		
		  public KeyManager getKeyManager(){
			    return keyManager;
			  }
			  public Canvas getCanvas() {
			    return canvas;
			  }
			
	
	
	
}